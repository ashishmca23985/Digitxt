The code block below uses HTTP POST to send an SMS via the EAPI. Copy, then Paste and modify it for your own use. Refer to the Microsoft documentation if you require more information on the Microsoft.XMLHTTP object, or http://www.bulksms.com/int/docs/eapi/ to see the EAPI documentation.


'=================================
'-- CODE START
'=================================

'-- forward declarations
Dim oHttp As Object
Dim strServer, strUsername, strPassword, strMessage, strMobileNumber, strData As String
Set oHttp = CreateObject("Microsoft.XMLHTTP")

'-- get message paramaters from screen fields
strUsername = "your_BulkSMS_username"
strPassword = "your_BulkSMS_password"
strMessage = "Hello world!"
strMobileNumber = "447882890000" 'comma seperated mobile list
strServer = "www.bulksms.co.uk"

'-- build the HTTP POST dataset
strData = "&username=" + strUsername + "&password=" + strPassword + "&message=" + strMessage + "&msisdn=" + strMobileNumber

'-- prepare the HTTP POST message
oHttp.Open "POST", "http://" + strServer + "/eapi/submission/send_sms/2/2.0", False
oHttp.setRequestHeader "User-Agent", "BulkSMS.Excel.Sample"
oHttp.setRequestHeader "Content-Type", "application/x-www-form-urlencoded"
oHttp.setRequestHeader "Accept", "*/*"
oHttp.setRequestHeader "Content-Length", CStr(Len(strMessage))
oHttp.setRequestHeader "Connection", "close"

'-- send the message
oHttp.send (strData)

'-- get the response
MsgBox (oHttp.responseText)



'=================================
'-- CODE END
'=================================

Also attached is a working Excel version of the above. Open the attached xlsm file, and enable Macro's for the workbook, then click anywhere on Sheet1. To edit the VBA code, press Alt+F11 and use the project explorer to edit,view the form and associated code.

