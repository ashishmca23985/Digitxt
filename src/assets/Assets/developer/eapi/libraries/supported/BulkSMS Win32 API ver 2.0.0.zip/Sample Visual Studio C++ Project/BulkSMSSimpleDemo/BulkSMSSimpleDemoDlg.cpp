// BulkSMSSimpleDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "BulkSMSSimpleDemo.h"
#include "BulkSMSSimpleDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CBulkSMSSimpleDemoDlg dialog
#include "..\..\smsapisimple.h"
#include ".\bulksmssimpledemodlg.h"

CBulkSMSSimpleDemoDlg::CBulkSMSSimpleDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBulkSMSSimpleDemoDlg::IDD, pParent)
	, m_strText(_T(""))
	, m_strMobileNO(_T(""))
	, m_strUsername(_T(""))
	, m_strPassword(_T(""))
	, m_strCboServer(_T(""))
	, m_strMsgID(_T(""))
	, m_strAPIVersion(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CBulkSMSSimpleDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_TXT_MESSAGE, m_strText);
	DDX_Text(pDX, IDC_TXT_MOBILE, m_strMobileNO);
	DDX_Text(pDX, IDC_TXT_USERNAME, m_strUsername);
	DDX_Text(pDX, IDC_TXT_PASSWORD, m_strPassword);
	DDX_CBString(pDX, IDC_CBO_SERVER, m_strCboServer);
	DDX_Text(pDX, IDC_TXT_MSGID, m_strMsgID);
	DDX_CBString(pDX, IDC_CBO_APIVERSION, m_strAPIVersion);
}

BEGIN_MESSAGE_MAP(CBulkSMSSimpleDemoDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_GETREPORT, OnBnClickedGetreport)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_BN_CLICKED(IDC_SENDSMS, OnBnClickedSendsms)
	ON_BN_CLICKED(IDC_SENDBATCH, OnBnClickedSendbatch)
	ON_BN_CLICKED(IDC_GETCREDITS, &CBulkSMSSimpleDemoDlg::OnBnClickedGetcredits)
	ON_BN_CLICKED(IDC_GETINBOX, &CBulkSMSSimpleDemoDlg::OnBnClickedGetinbox)
	ON_BN_CLICKED(IDC_GETAPIVERSION, &CBulkSMSSimpleDemoDlg::OnBnClickedGetapiversion)
END_MESSAGE_MAP()


// CBulkSMSSimpleDemoDlg message handlers

BOOL CBulkSMSSimpleDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	((CComboBox*)GetDlgItem(IDC_CBO_APIVERSION))->SetCurSel(1);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CBulkSMSSimpleDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CBulkSMSSimpleDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CBulkSMSSimpleDemoDlg::OnBnClickedGetreport()
{
	
	UpdateData(TRUE);

	//-- you should step into the Simple_ sample functions to see how the API is used

	//-- make sure the following function can find the dll.
	if (!SMSAPISimple_Init(m_strAPIVersion))
	{
		MessageBox("Cannot load/find SMSAPI Win 32 DLL. If necessary, copy the DLL to the project folder.\n\nAlso check that the correct version of the DLL exist in the current path - earlier versions of the DLL will fail to load.","",0);
		return;
	}

	//-- buffer for report data 
	char szReport[1024];// increase this buffer if getting a report for large batches
		
	//its best to step into the BulkSMSSimple_SendSMS function to see how it uses the DLL
	if (SMSAPISimple_GetReport(m_strUsername,m_strPassword, GetServerID(), atoi(m_strMsgID), szReport, sizeof(szReport)))
	{
		//success
	}
	
	SMSAPISimple_CleanUp();

}

int CBulkSMSSimpleDemoDlg::GetServerID(void)
{
	
	int nServerID = 0;

	if (m_strCboServer.Find("co.za") >= 0)
		nServerID = SMSAPI_SERVER_CO_ZA;
	else if (m_strCboServer.Find("co.uk") >= 0)
		nServerID = SMSAPI_SERVER_CO_UK;
	else if (m_strCboServer.Find(".es") >= 0)
		nServerID = SMSAPI_SERVER_ES;
	else if (m_strCboServer.Find(".de") >= 0)
		nServerID = SMSAPI_SERVER_DE;
	else if (m_strCboServer.Find(".net") >= 0)
		nServerID = SMSAPI_SERVER_NET;
	else if (m_strCboServer.Find("usa.") >= 0)
		nServerID = SMSAPI_SERVER_CO_US;
	else if (m_strCboServer.Find("community.uk") >= 0)
		nServerID = SMSAPI_SERVER_COMMUNITY_CO_UK;

	return nServerID;
}

void CBulkSMSSimpleDemoDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	OnOK();
}

void CBulkSMSSimpleDemoDlg::OnBnClickedSendsms()
{

	UpdateData(TRUE);

	//-- you should step into the Simple_ sample functions to see how the API is used

	//-- make sure the following function can find the dll. Step into it to make sure. if necessary, copy the dll to the project folder
	if (SMSAPISimple_Init(m_strAPIVersion))
	{
		//call the sample send sms function
		if (SMSAPISimple_SendSMS(m_strUsername,m_strPassword, m_strMobileNO, m_strText, GetServerID()))
		{
			//success
		}
		SMSAPISimple_CleanUp();
	}
}

void CBulkSMSSimpleDemoDlg::OnBnClickedSendbatch()
{
	UpdateData(TRUE);

	//-- you should step into the Simple_ sample functions to see how the API is used

	//-- make sure the following function can find the dll. Step into it to make sure. if necessary, copy the dll to the project folder
	if (!SMSAPISimple_Init(m_strAPIVersion))
	{
		MessageBox("Cannot load/find SMSAPI Win 32 DLL. If necessary, copy the DLL to the project folder.\n\nAlso check that the correct version of the DLL exist in the current path - earlier versions of the DLL will fail to load.","",0);
		return;
	}
	
	//-- create an array of 4 items (1 for each item on the screen)
	LPSMSAPI_BATCHITEM lpArray = new SMSAPI_BATCHITEM[4];

	

	//-- copy from screen to the array
	GetDlgItemText(IDC_TXT_BNUM1,lpArray[0].szMobileNumber,SMSAPI_LEN_MOBILE);
	GetDlgItemText(IDC_TXT_BNUM2,lpArray[1].szMobileNumber,SMSAPI_LEN_MOBILE);
	GetDlgItemText(IDC_TXT_BNUM3,lpArray[2].szMobileNumber,SMSAPI_LEN_MOBILE);
	GetDlgItemText(IDC_TXT_BNUM4,lpArray[3].szMobileNumber,SMSAPI_LEN_MOBILE);

	GetDlgItemText(IDC_TXT_BMSG1,lpArray[0].szStandardMessageText,SMSAPI_LEN_STANDARD_MSG);
	GetDlgItemText(IDC_TXT_BMSG2,lpArray[1].szStandardMessageText,SMSAPI_LEN_STANDARD_MSG);
	GetDlgItemText(IDC_TXT_BMSG3,lpArray[2].szStandardMessageText,SMSAPI_LEN_STANDARD_MSG);
	GetDlgItemText(IDC_TXT_BMSG4,lpArray[3].szStandardMessageText,SMSAPI_LEN_STANDARD_MSG);

	//-- call the sampe send batch function. 
	/* NOTE: This sample requires all 4 screen locations to be populated with info. Eiether include all info, or modify the call 
	below to work with less  */
	SMSAPISimple_SendBatch(m_strUsername,m_strPassword,lpArray,4/*size of array*/,GetServerID());

	//-- delete the array
	delete [] lpArray;

	//-- clean-up
	SMSAPISimple_CleanUp();
}


void CBulkSMSSimpleDemoDlg::OnBnClickedGetcredits()
{
	//*********************
	UpdateData(TRUE);

	//-- you should step into the Simple_ sample functions to see how the API is used

	//-- make sure the following function can find the dll.
	if (!SMSAPISimple_Init(m_strAPIVersion))
	{
		MessageBox("Cannot load/find SMSAPI Win 32 DLL. If necessary, copy the DLL to the project folder.\n\nAlso check that the correct version of the DLL exist in the current path - earlier versions of the DLL will fail to load.","",0);
		return;
	}

	//-- buffer for report data 
	char szReport[1024];// increase this buffer if getting a report for large batches
		
	//its best to step into the BulkSMSSimple_SendSMS function to see how it uses the DLL
	if (SMSAPISimple_GetCredits(m_strUsername,m_strPassword, GetServerID(), szReport, sizeof(szReport)))
	{
		//success
	}
	
	SMSAPISimple_CleanUp();
}


void CBulkSMSSimpleDemoDlg::OnBnClickedGetinbox()
{
	//*********************
	UpdateData(TRUE);

	//-- you should step into the Simple_ sample functions to see how the API is used

	//-- make sure the following function can find the dll.
	if (!SMSAPISimple_Init(m_strAPIVersion))
	{
		MessageBox("Cannot load/find SMSAPI Win 32 DLL. If necessary, copy the DLL to the project folder.\n\nAlso check that the correct version of the DLL exist in the current path - earlier versions of the DLL will fail to load.","",0);
		return;
	}

	//-- buffer for report data 
	char szReport[1024*50];// increase this buffer if getting a report for large batches
		
	//its best to step into the SMSAPISimple_GetInbox function to see how it uses the DLL
	if (SMSAPISimple_GetInbox(m_strUsername,m_strPassword, GetServerID(), atoi(m_strMsgID), szReport, sizeof(szReport)))
	{
		//success
	}
	
	SMSAPISimple_CleanUp();
	
}

void CBulkSMSSimpleDemoDlg::OnBnClickedGetapiversion()
{
	UpdateData(TRUE);//get the screen data into variables (part of the MFC design)

	if (!SMSAPISimple_Init(m_strAPIVersion))
	{
		MessageBox("Cannot load/find SMSAPI Win 32 DLL. If necessary, copy the DLL to the project folder.\n\nAlso check that the correct version of the DLL exist in the current path - earlier versions of the DLL will fail to load.","",0);
		return;
	}

	char szVerInfo[256];
	if (SMSAPISimple_GetApiVersion(szVerInfo))
		MessageBox(szVerInfo,"",0);
	else
		MessageBox("Function failed. Is your input string large enough?/","",0);
	

}
