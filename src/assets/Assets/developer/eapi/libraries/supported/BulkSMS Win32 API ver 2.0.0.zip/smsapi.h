/*
	this header contains definitions for the bulksms api
*/

//-- length definitions
#define SMSAPI_LEN_STANDARD_BUFFER				255
#define SMSAPI_LEN_MOBILE						20
#define SMSAPI_LEN_STANDARD_MSG					160 /* STANDARD GSM DEFINED TEXT MESSAGE LENGTH				*/
#define SMSAPI_LEN_LONG_MSG						918	/* CONCAT PART LEN (153) * MAX CONCAT PARTS (6) = 918	*/
#define SMSAPI_LEN_SCHEDULE_DATETIME			14


//-- response info results
#define SMSAPI_VALIDATION_ERROR_NETCONFIG		-1	
#define SMSAPI_VALIDATION_ERROR_ACCOUNTINFO		-2
#define SMSAPI_VALIDATION_ERROR_MESSAGEINFO		-3	
#define SMSAPI_VALIDATION_ERROR_BATCHINFO		-4
#define SMSAPI_VALIDATION_ERROR_BATCHARRAY		-5
#define SMSAPI_VALIDATION_ERROR_BATCHEXCEPTION	-6
#define SMSAPI_VALIDATION_ERROR_SERVERID		-7
#define SMSAPI_VALIDATION_ERROR_SCHEDDATETIME	-8
#define SMSAPI_VALIDATION_ERROR_MOBILELIST		-9
#define SMSAPI_VALIDATION_ERROR_MESSAGEID		-10
#define SMSAPI_VALIDATION_ERROR_BUFFERTOOSMALL	-11


typedef enum tagSMSAPI_SERVER
{
	SMSAPI_SERVER_NOT_DEFINED = 0,
	SMSAPI_SERVER_CO_ZA,				//-- south africa
	SMSAPI_SERVER_CO_UK,				//-- united kingdom
	SMSAPI_SERVER_CO_US,				//-- united states
	SMSAPI_SERVER_DE,					//-- germany
	SMSAPI_SERVER_ES,					//-- spain
	SMSAPI_SERVER_NET,					//-- all other countries (international)
	SMSAPI_SERVER_COMMUNITY_CO_UK,		//-- community united kingdom
	SMSAPI_SERVER_COMMUNITY_CO_ZA,		//-- community south africa
	SMSAPI_SERVER_WHITELABEL			//-- white label servers
} SMSAPI_SERVER, *LPSMSAPI_SERVER;


typedef struct tagSMSAPI_NETWORKCONFIGURATION 
{
	bool bKeepConnectionAlive;
	bool bUseSSL;
	HWND hWndUI;
	int nAcessType;
	int nIdealPort;
	int nProxyPort;
	char szProxyAddress[SMSAPI_LEN_STANDARD_BUFFER + 1];
	char szProxyUsername[SMSAPI_LEN_STANDARD_BUFFER + 1];
	char szProxyPassword[SMSAPI_LEN_STANDARD_BUFFER + 1];
} SMSAPI_NETWORKCONFIGURATION, *LPSMSAPI_NETWORKCONFIGURATION;

typedef struct tagSMSAPI_ACCOUNTINFO
{
	char szSMSAPIUsername[SMSAPI_LEN_STANDARD_BUFFER + 1];
	char szSMSAPIPassword[SMSAPI_LEN_STANDARD_BUFFER + 1];
	SMSAPI_SERVER defaultServerID;
	char szServerOverride[SMSAPI_LEN_STANDARD_BUFFER + 1];
} SMSAPI_ACCOUNTINFO, *LPSMSAPI_ACCOUNTINFO;

typedef struct tagSMSAPI_MESSAGEINFO
{
	const char * lpszCommaSeperatedMobileList;
	char szMessageText[SMSAPI_LEN_LONG_MSG + 1];
	char szSenderID[SMSAPI_LEN_STANDARD_BUFFER + 1];
	bool bLongMessage;
	int nMaxLongMessageParts;
	bool bScheduleForLaterDelivery;
	char szScheduleYYYYMMDDHHMMSS[SMSAPI_LEN_SCHEDULE_DATETIME + 1];
	int nMessageClass;
	unsigned long dwMessageID;
} SMSAPI_MESSAGEINFO, *LPSMSAPI_MESSAGEINFO;

typedef struct tagSMSAPI_BATCHITEM	
{
	char szMobileNumber[SMSAPI_LEN_MOBILE + 1];
	char szStandardMessageText[SMSAPI_LEN_STANDARD_MSG + 1];
} SMSAPI_BATCHITEM, *LPSMSAPI_BATCHITEM;

typedef struct tagSMSAPI_BATCHINFO
{
	LPSMSAPI_BATCHITEM lpBatchItemArray;
	int nBatchItemArrayItemCount;
	char szSenderID[SMSAPI_LEN_STANDARD_BUFFER + 1];
	bool bScheduleForLaterDelivery;
	char szScheduleYYYYMMDDHHMMSS[SMSAPI_LEN_SCHEDULE_DATETIME + 1];
	int nMessageClass;
	unsigned long dwMessageID;
} SMSAPI_BATCHINFO, *LPSMSAPI_BATCHINFO;

typedef struct tagSMSAPI_RESPONSEINFO
{
	int cbSizeOfResultBuffer;
	char * lpszResult;
	int nResult;
} SMSAPI_RESPONSEINFO, *LPSMSAPI_RESPONSEINFO;

typedef struct tagSMSAPI_APIVERSIONINFO
{
	int ver_major;
	int ver_minor;
	int ver_build;
	int ver_hash;
	char ver_string[SMSAPI_LEN_STANDARD_BUFFER+1];
} SMSAPI_APIVERSIONINFO, *LPSMSAPI_APIVERSIONINFO;

//-- API function definitions 
typedef bool (__stdcall* SMSAPIFUNCTION_GETAPIVERSION)(LPSMSAPI_APIVERSIONINFO);
typedef bool (__stdcall* SMSAPIFUNCTION_SENDSMS)(const LPSMSAPI_NETWORKCONFIGURATION, const LPSMSAPI_ACCOUNTINFO , const LPSMSAPI_MESSAGEINFO, LPSMSAPI_RESPONSEINFO);
typedef bool (__stdcall* SMSAPIFUNCTION_SENDBATCH)(const LPSMSAPI_NETWORKCONFIGURATION, const LPSMSAPI_ACCOUNTINFO , const LPSMSAPI_BATCHINFO, LPSMSAPI_RESPONSEINFO);
typedef bool (__stdcall* SMSAPIFUNCTION_INITIALIZE_DEFAULTS)(void* lpData, int cbSize);
typedef bool (__stdcall* SMSAPIFUNCTION_GETREPORT)(const LPSMSAPI_NETWORKCONFIGURATION, const LPSMSAPI_ACCOUNTINFO, const DWORD, LPSMSAPI_RESPONSEINFO);
typedef bool (__stdcall* SMSAPIFUNCTION_GETINBOX)(const LPSMSAPI_NETWORKCONFIGURATION, const LPSMSAPI_ACCOUNTINFO, const DWORD, LPSMSAPI_RESPONSEINFO);
typedef bool (__stdcall* SMSAPIFUNCTION_GETCREDITS)(const LPSMSAPI_NETWORKCONFIGURATION, const LPSMSAPI_ACCOUNTINFO, LPSMSAPI_RESPONSEINFO);

