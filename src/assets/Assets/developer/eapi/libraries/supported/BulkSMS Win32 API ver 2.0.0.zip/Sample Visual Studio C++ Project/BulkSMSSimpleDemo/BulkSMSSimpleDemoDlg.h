// BulkSMSSimpleDemoDlg.h : header file
//

#pragma once


// CBulkSMSSimpleDemoDlg dialog
class CBulkSMSSimpleDemoDlg : public CDialog
{
// Construction
public:
	CBulkSMSSimpleDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_BULKSMSSIMPLEDEMO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString m_strText;
	CString m_strMobileNO;
	CString m_strUsername;
	CString m_strPassword;
	CString m_strCboServer;
	CString m_strMsgID;
	CString m_strAPIVersion;
	int GetServerID(void);
	
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedGetreport();
	afx_msg void OnBnClickedSendsms();
	afx_msg void OnBnClickedSendbatch();
	afx_msg void OnBnClickedGetcredits();
	afx_msg void OnBnClickedGetinbox();
	afx_msg void OnBnClickedGetapiversion();
};
