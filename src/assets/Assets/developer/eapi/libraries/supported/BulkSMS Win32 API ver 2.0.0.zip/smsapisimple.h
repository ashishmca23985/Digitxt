

#include "smsapi.h" //-- change the location if need be or copy the header file to the project folder

bool SMSAPISimple_Init(const char * lpszAPIFilename);
bool SMSAPISimple_CleanUp(void);
int SMSAPISimple_SendSMS(const char * lpszUsername, const char * lpszPassword, const char * lpszMobile, const char * lpszMessage, int serverID);
int SMSAPISimple_SendBatch(const char * lpszUsername, const char * lpszPassword, const LPSMSAPI_BATCHITEM lpArray, const int nArrayItemCount, int serverID);
int SMSAPISimple_GetReport(const char * lpszUsername, const char * lpszPassword, const int serverID, const unsigned long dwMessageID, char * szReportData, int nSize);
int SMSAPISimple_GetInbox(const char * lpszUsername, const char * lpszPassword, const int serverID, const unsigned long dwMessageID, char * szReportData, int nSize);
int SMSAPISimple_GetCredits(const char * lpszUsername, const char * lpszPassword, const int serverID, char * szReportData, int nSize);
bool SMSAPISimple_GetApiVersion(char * lpszVersionInfo);


