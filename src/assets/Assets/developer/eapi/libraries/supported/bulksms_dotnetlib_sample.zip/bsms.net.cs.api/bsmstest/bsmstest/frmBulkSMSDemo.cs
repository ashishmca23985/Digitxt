using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace bsmstest
{
    public partial class frmBulkSMSDemo : Form
    {
        public frmBulkSMSDemo()
        {
            InitializeComponent();
            txtHTTPData.Text = "http://www.bulksms.co.uk:5567/eapi/submission/send_sms/2/2.0?username=your_username&password=your_password&message=your message goes here&want_report=1&msisdn=447882893997";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bulksms_dotnetlib.CBSMS_Http smstext = new bulksms_dotnetlib.CBSMS_Http();
            txtResult.Text = smstext.HTTPSend(txtHTTPData.Text);
            
        }
    }
}